import json



x = int(input("Masukkan Jumlah karyawan Baru : ")) 

    

for i in range(x): 
    nama = []
    a = input("Masukkan nama  : ") 
    # nama = {} 
    # nama[a] =[] 

    d = input("Masukkan alamat : ") 
    # nama["Alamat"] = d
    list_kolega = []  
    dictkol = dict()
    dictal = dict()

    b = int(input("Masukkan Jumlah kolega : "))
    for j in range (1,b+1):
        c = input("Masukkan nama kolega ke-{}: ".format(j))
        list_kolega.append(c) 
        # nama["Kolega"]  = list_kolega 
    
    dictal["Alamat"] = d 
    dictkol["Kolega"] = list_kolega

    nama.append(dictal)
    nama.append(dictkol) 
    print('=== Data berhasil ditambahkan ===') 


# nama = {} 
# nama[a] =[]
# nama["Alamat"] = d
# nama["Kolega"]  = list_kolega 

# data[a] = nama
    with open('karyawan.json','r') as datafile:
        data = json.load(datafile)
        data[a] = nama
    with open('karyawan.json','w') as datafile:
        json.dump(data, datafile)